package com.hcl.abcstock.errors;

public class StockNotAvailableException extends Exception{
	public StockNotAvailableException(String str) {
		super(str);
	}

}
